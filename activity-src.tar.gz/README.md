# Void Arena Live v4.2.2 — Render Dev

Base estavel do relay WebCodecs + WebSocket, preparada para uma URL fixa no Render e para atualizacoes via GitHub sem reinstalar no PC ou trocar Tunnel.

Veja `README_RENDER.md` para o deploy.

Esta versão corrige o fluxo de vídeo dentro da Discord Activity.

## O que mudou

A v4.1.x tentava usar `RTCPeerConnection` dentro do iframe da Activity. Nos testes reais do Discord, o estado da transmissão sincronizava, mas o vídeo falhava com `RTCPeerConnection is not a constructor`.

A v4.2.1 volta ao caminho que já tinha funcionado no teste original:

**captura externa -> WebCodecs -> WebSocket -> Activity -> WebCodecs -> canvas**

Assim, a Activity não depende de `RTCPeerConnection`.

## Teste local

1. Feche todos os CMDs das versões antigas.
2. Rode `1-INSTALAR.bat` uma vez.
3. Rode `0-INICIAR.bat`.
4. Copie a URL `https://...trycloudflare.com` da janela Tunnel.
5. No Discord Developer Portal, atualize `Atividades > Mapeamentos de URL` com o novo domínio.
6. Feche e abra a Activity do Void Arena na call.
7. Clique em **Transmitir minha tela**, selecione a janela/tela e volte ao Discord.

A porta local desta versão é **3420** para não misturar com servidores antigos.

## Diagnóstico esperado

No CMD do servidor devem aparecer as mesmas salas para viewer e broadcaster, por exemplo:

```text
[WS] viewer join room=call-...
[WS] broadcaster register room=call-...
[WS] stream-started room=call-...
```

Na Activity, quando o vídeo chegar, a barra inferior deve mostrar algo parecido com:

```text
Relay • 30 FPS • 3.2 Mb/s • 40 ms
```

## Áudio / eco

O modo **Seguro contra eco** continua ativo por padrão. Se a captura for o monitor inteiro ou incluir o Discord, o áudio é desligado para evitar retransmitir a própria call. Para áudio do jogo, prefira compartilhar a janela do jogo quando o navegador oferecer áudio por janela.

## Qualidade

- 480p
- 720p
- 1080p
- 1440p / 2K
- Automático
- 30 / 60 FPS

No modo Automático, a v4.2.1 reduz a qualidade global se a fila de envio crescer ou os espectadores começarem a receber poucos frames, priorizando atraso baixo.

> Durante esta versão de estabilidade, o fluxo codificado é único por transmissão. Portanto, a preferência de qualidade de um espectador pode limitar a qualidade global quando o transmissor está em Automático. Depois da validação de estabilidade, uma arquitetura com múltiplas camadas/SFU pode permitir qualidade verdadeiramente independente por espectador.

## Render

Ainda teste esta versão localmente primeiro. O vídeo agora passa pelo servidor WebSocket; colocar exatamente este transporte no Render consumiria tráfego de saída. A hospedagem 24/7 deve ser feita depois de validarmos o fluxo de mídia e escolhermos a arquitetura final de distribuição.


## v4.2.1
- A qualidade escolhida pelo espectador agora realmente limita o encoder do fluxo relay (um único fluxo da sala).
- A resolução real recebida aparece ao lado do seletor.
- O painel inferior pode ser minimizado até virar um botão pequeno e pode ser arrastado para qualquer canto da transmissão.
- Duplo clique no botão de arrastar restaura a posição padrão.