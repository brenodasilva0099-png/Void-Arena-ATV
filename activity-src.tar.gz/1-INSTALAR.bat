@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Void Arena Live v4.2.1 - Instalacao

where node >nul 2>&1
if errorlevel 1 (
  echo [ERRO] Node.js nao foi encontrado.
  echo Instale Node.js 20.19 ou superior e rode este arquivo novamente.
  echo https://nodejs.org/
  pause
  exit /b 1
)

where cloudflared >nul 2>&1
if errorlevel 1 (
  echo [INFO] cloudflared nao encontrado. Tentando instalar pelo winget...
  winget install --id Cloudflare.cloudflared -e --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo [ERRO] Nao consegui instalar o cloudflared automaticamente.
    echo Rode manualmente: winget install --id Cloudflare.cloudflared
    pause
    exit /b 1
  )
)

echo.
echo Instalando dependencias...
call npm install
if errorlevel 1 (
  echo [ERRO] Falha no npm install.
  pause
  exit /b 1
)

echo.
echo Validando projeto...
call npm run check
if errorlevel 1 (
  echo [ERRO] A validacao encontrou um problema.
  pause
  exit /b 1
)

echo.
echo [OK] Instalacao concluida.
echo Use 0-INICIAR.bat para testes locais.
pause
